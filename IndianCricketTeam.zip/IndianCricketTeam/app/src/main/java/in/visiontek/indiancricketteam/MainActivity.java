package in.visiontek.indiancricketteam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.ktx.Firebase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

RecyclerView recyclerView;
ArrayList<cricketer> cricketerArraylist;
String spinnerplayer1,spinnerrole1;
FirebaseDatabase firebaseDatabase;
Button addButton;
DatabaseReference databaseReference;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recycle_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference("CricketTeam");
        loadData();

        //CricketerAdapter cricketerAdapter = new CricketerAdapter(this, cricketerArraylist);
       // recyclerView.setAdapter(cricketerAdapter);

    }

    private void loadData() {
        databaseReference=FirebaseDatabase.getInstance().getReference("CricketTeam");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cricketerArraylist=new ArrayList<>();
                for (DataSnapshot dataSnapshot:snapshot.getChildren()){
                    cricketer team=dataSnapshot.getValue(cricketer.class);
                    cricketerArraylist.add(team);
                }

                CricketerAdapter cricketerAdapter=new CricketerAdapter(getApplicationContext(),cricketerArraylist);
                recyclerView.setAdapter(cricketerAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }


        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==R.id.option_add_nature){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(R.layout.team_alert);
            builder.setTitle("Add Cricketer names");
            AlertDialog dialog = builder.create();
            dialog.show();
            Spinner spinnerplayer = dialog.findViewById(R.id.Spinner);
            Spinner spinnerrole = dialog.findViewById(R.id.Spinner1);
            addButton = dialog.findViewById(R.id.add_button);
            addButton.setText(R.string.add);
            ArrayAdapter<CharSequence> arrayAdapter=ArrayAdapter.createFromResource(getApplicationContext(),R.array.team_array,
                    android.R.layout.simple_spinner_dropdown_item);
            spinnerplayer.setAdapter(arrayAdapter);
            ArrayAdapter<CharSequence> arrayAdapter1=ArrayAdapter.createFromResource(getApplicationContext(),R.array.role_array,
                    android.R.layout.simple_spinner_dropdown_item);

            spinnerrole.setAdapter(arrayAdapter1);
            spinnerplayer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    spinnerplayer1=spinnerplayer.getItemAtPosition(position).toString();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            spinnerrole.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    spinnerrole1=spinnerrole.getItemAtPosition(position).toString();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addDataToFirebase(spinnerplayer1,spinnerrole1);
                    dialog.dismiss();
                    loadData();
                }



                /*private void loadData() {
                    databaseReference=FirebaseDatabase.getInstance().getReference("CricketTeam");
                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            cricketerArraylist=new ArrayList<>();
                          for (DataSnapshot dataSnapshot:snapshot.getChildren()){
                              cricketer team=dataSnapshot.getValue(cricketer.class);
                              cricketerArraylist.add(team);
                          }

                            CricketerAdapter cricketerAdapter=new CricketerAdapter(getApplicationContext(),cricketerArraylist);
                            recyclerView.setAdapter(cricketerAdapter);

                    }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }


                        });
                }*/
                private void addDataToFirebase(String spinnerplayer1, String spinnerrole1) {
                    cricketer cricketerteams=new cricketer(spinnerplayer1,spinnerrole1);
                    databaseReference.push().setValue(cricketerteams);

                }
                });


        }
            return super.onOptionsItemSelected(item);
    }
    }

