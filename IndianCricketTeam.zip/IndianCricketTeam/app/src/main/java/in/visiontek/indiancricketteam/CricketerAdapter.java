package in.visiontek.indiancricketteam;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class CricketerAdapter extends RecyclerView.Adapter<CricketerAdapter.MyViewHolder> {
    ArrayList<cricketer> cricketerArrayList;
    Context context;
    int currentposition;
    DatabaseReference databaseReference;

    public CricketerAdapter(Context context, ArrayList<cricketer> cricketerArraylist) {
        this.context=context;
        this.cricketerArrayList=cricketerArraylist;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item,parent,false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull CricketerAdapter.MyViewHolder holder, int position) {
        cricketer mycricket = cricketerArrayList.get(position);
        holder.name.setText(mycricket.getName());
        holder.role.setText(mycricket.getRole());
        holder.image.setImageResource(mycricket.getImage());
        if(mycricket.getRole().equals("All-Rounder")){
            holder.image.setImageResource(R.drawable.allroundercricket);

        }
        if (mycricket.getRole().equals("Bowler")){
            holder.image.setImageResource(R.drawable.ball);
        }
        if (mycricket.getRole().equals("Batsman")){
            holder.image.setImageResource(R.drawable.bat);
        }
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {

                PopupMenu popupMenu = new PopupMenu(context, v);
                currentposition = holder.getAdapterPosition();
                popupMenu.getMenuInflater().inflate(R.menu.popu_menu, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getItemId() == R.id.edit) {
                            editEmployee();
                        } else if (item.getItemId() == R.id.delete) {
                            deleteItem();
                        }

                        return true;
                    }

                    private void deleteItem() {
                        cricketer cricketer1 = cricketerArrayList.get(currentposition);
                        databaseReference = FirebaseDatabase.getInstance().getReference("CricketTeam");
                        Query query = databaseReference.orderByChild("name").equalTo(cricketer1.getName());
                        query.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    dataSnapshot.getRef().removeValue();
                                    notifyDataSetChanged();
                                }

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                    }

                    private void editEmployee() {
                    }
                });
                popupMenu.show();
                return true;
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(context,SelectedPlayer.class);

                in.putExtra("CricketTeam",mycricket);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(in);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cricketerArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, role;
        ImageView image;
        public MyViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.emp_name);
            role = view.findViewById(R.id.emp_email);
            image=view.findViewById(R.id.roleimagelist);
        }
    }
}
