package in.visiontek.indiancricketteam;

import android.widget.Spinner;

import java.io.Serializable;

public class cricketer implements Serializable {
    String name, role;
    int image;

    public cricketer(int image) {
        this.image = image;
    }

    public cricketer(String name, String role) {
        this.name = name;
        this.role = role;

    }

    public cricketer() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}