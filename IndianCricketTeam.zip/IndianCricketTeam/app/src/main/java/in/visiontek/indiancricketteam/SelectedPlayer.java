package in.visiontek.indiancricketteam;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class SelectedPlayer extends AppCompatActivity {
TextView player,role;
ImageView imageView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_player);
        player=findViewById(R.id.playername);
        role=findViewById(R.id.playerrole);
        imageView=findViewById(R.id.roleimageview);
        Intent in=getIntent();
        cricketer cricketIndia=(cricketer) in.getSerializableExtra("CricketTeam");
        player.setText(cricketIndia.getName());
        role.setText(cricketIndia.getRole());
        imageView.setImageResource(cricketIndia.getImage());
        if(cricketIndia.getRole().equals("All-Rounder")){
            imageView.setImageResource(R.drawable.allroundercricket);

        }
        if (cricketIndia.getRole().equals("Bowler")){
            imageView.setImageResource(R.drawable.ball);
        }
        if (cricketIndia.getRole().equals("Batsman")){
            imageView.setImageResource(R.drawable.bat);
        }
    }
}