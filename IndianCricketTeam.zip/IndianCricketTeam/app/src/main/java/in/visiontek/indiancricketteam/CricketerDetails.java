package in.visiontek.indiancricketteam;

public class CricketerDetails {
}
